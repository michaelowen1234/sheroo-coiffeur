# Sheroo Coiffeur – Website Variante 2 (modern)

Eine einzige `index.html` plus Ordner `assets` (Bilder). Kein Build nötig.

## Veröffentlichen (GitHub Pages)
Repository erstellen, `index.html`, `.nojekyll` und den Ordner `assets` hochladen. Settings → Pages → Branch `main`, Ordner `/ (root)` → Save.

## Noch auszufüllen (gold umrandet, Klasse `todo`)
- Stornofrist und Gebühr (Abschnitt «Termin anfragen»)
- Stand-Datum in Datenschutz und AGB, Zahlungsarten in den AGB
- UID/MWST im Impressum, falls vorhanden

Die Rechtstexte sind Vorlagen (Schweiz) und ersetzen keine Rechtsberatung.
