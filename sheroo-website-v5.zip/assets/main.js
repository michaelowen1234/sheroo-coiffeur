(function(){
  // ====== Hier eintragen ======
  var EMAIL = "info@example.ch"; // TODO: echte E-Mail-Adresse des Salons
  // ============================
  var KEY="sheroo-consent", cc=document.getElementById("cc");
  function loadFonts(){
    if(document.getElementById("gf"))return;
    var l=document.createElement("link");l.id="gf";l.rel="stylesheet";
    l.href="https://fonts.googleapis.com/css2?family=Cormorant+Garamond:wght@500;600;700&family=Jost:wght@400;500&display=swap";
    document.head.appendChild(l);
  }
  function get(){try{return localStorage.getItem(KEY)}catch(e){return null}}
  function set(v){try{localStorage.setItem(KEY,v)}catch(e){}}
  function show(){cc.hidden=false}
  function hide(){cc.hidden=true}
  if(get()==="all")loadFonts();else if(!get())show();
  document.getElementById("cc-yes").onclick=function(){set("all");loadFonts();hide()};
  document.getElementById("cc-no").onclick=function(){set("necessary");hide()};
  document.getElementById("cc-open").onclick=show;

  document.getElementById("yr").textContent=new Date().getFullYear();
  var d=new Date().getDay(),row=document.querySelector('.hours tr[data-d="'+d+'"]');
  if(row)row.classList.add("today");
  var m=document.querySelector("[data-mail]");
  if(m&&EMAIL.indexOf("example.ch")<0){m.href="mailto:"+EMAIL;m.textContent=EMAIL;m.classList.remove("todo")}

  var f=document.getElementById("book");
  if(f){
    var dt=document.getElementById("f-date");dt.min=new Date().toISOString().slice(0,10);
    var sum=document.getElementById("f-sum"),boxes=[].slice.call(f.querySelectorAll('input[name="svc"]'));
    function picked(){return boxes.filter(function(b){return b.checked})}
    function upd(){
      var p=picked(),t=0;p.forEach(function(b){t+=+b.dataset.p});
      sum.classList.remove("err");
      sum.innerHTML=p.length?p.length+" Leistung"+(p.length>1?"en":"")+" gewählt · Total <strong>CHF "+t+".–</strong>":"Bitte wählen Sie mindestens eine Leistung.";
    }
    boxes.forEach(function(b){b.addEventListener("change",upd)});
    f.addEventListener("submit",function(e){
      e.preventDefault();
      var p=picked();
      if(!p.length){sum.classList.add("err");sum.textContent="Bitte wählen Sie mindestens eine Leistung.";boxes[0].focus();return}
      if(!f.reportValidity())return;
      var v=function(n){return f.elements[n].value.trim()},t=0;
      p.forEach(function(b){t+=+b.dataset.p});
      var svc=p.map(function(b){return "- "+b.value+" ("+b.dataset.p+".–)"}).join("\n");
      var body=["Terminanfrage","","Name: "+v("name"),"Telefon: "+v("tel"),"E-Mail: "+(v("mail")||"-"),"",
        "Dienstleistungen:",svc,"Total: CHF "+t+".–","","Wunschdatum: "+(v("date")||"-"),"Wunschzeit: "+(v("time")||"-"),"","Nachricht:",v("msg")||"-"].join("\n");
      window.location.href="mailto:"+EMAIL+"?subject="+encodeURIComponent("Terminanfrage von "+v("name"))+"&body="+encodeURIComponent(body);
    });
  }
  // Menü
  var mb=document.getElementById("mb"),mp=document.getElementById("mp");
  function menu(o){mp.hidden=!o;mb.setAttribute("aria-expanded",o);document.querySelector("header").classList.toggle("open",o);document.body.classList.toggle("menu-open",o)}
  mb.addEventListener("click",function(){menu(mp.hidden)});
  mp.addEventListener("click",function(e){if(e.target.closest("a"))menu(false)});
  document.addEventListener("keydown",function(e){if(e.key==="Escape")menu(false)});
})();
