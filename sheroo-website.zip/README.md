# Sheroo Coiffeur – Website (GitHub Pages)

Reine HTML/CSS/JS-Seite, kein Build nötig.

## Dateien
- `index.html` Startseite (Preise, Öffnungszeiten, Terminanfrage, Stornierung, Kontakt & Anfahrt)
- `impressum.html`, `datenschutz.html`, `agb.html`
- `assets/style.css`, `assets/main.js`, `assets/logo.jpg`, `assets/salon.jpg`, `assets/details.jpg`, `assets/favicon.png`

## Zuerst ausfüllen (nach `todo` oder `[…]` suchen)
1. `assets/main.js`: Zeile `var EMAIL = ...` mit der echten E-Mail-Adresse ersetzen.
2. `index.html`: Stornierungsfrist und -gebühr. (Öffnungszeiten sind eingetragen: Mo–Fr 09:00–19:00.)
3. `impressum.html`: UID/MWST falls vorhanden, E-Mail. (Inhaber ist eingetragen.)
4. `datenschutz.html` und `agb.html`: Datum, E-Mail, Zahlungsarten.
5. In allen Dateien `info@example.ch` durch die echte Adresse ersetzen.
6. Die gold umrandeten Platzhalter (Klasse `todo`) danach entfernen.

## Veröffentlichen
Repository erstellen, alle Dateien hochladen, dann Settings → Pages → Branch `main`, Ordner `/ (root)` → Save.

## Hinweise
- Die Rechtstexte sind Standardvorlagen für die Schweiz (DSG) und ersetzen keine Rechtsberatung. Bitte vor dem Livegang prüfen lassen.
- Das Formular öffnet das E-Mail-Programm (`mailto:`). Für echte Online-Buchung mit Kalender wäre ein Dienst wie Calendly oder Treatwell nötig; der Link kann dann beim Button «Termin anfragen» eingesetzt werden.
- Google Fonts werden nur nach Zustimmung im Cookie-Banner geladen.
